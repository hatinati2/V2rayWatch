package com.linkwatch.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkwatch.app.LinkWatchApplication
import com.linkwatch.app.core.ProxyLinkParser
import com.linkwatch.app.core.XrayDelayTester
import com.linkwatch.app.data.LinkState
import com.linkwatch.app.data.MonitorSettings
import com.linkwatch.app.data.ProfileRepository
import com.linkwatch.app.data.ProxyProfile
import com.linkwatch.app.monitor.MonitorController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


data class LinkWatchUiState(
    val profiles: List<ProxyProfile> = emptyList(),
    val settings: MonitorSettings = MonitorSettings(),
    val monitoring: Boolean = false,
    val busy: Boolean = false,
    val message: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ProfileRepository = (application as LinkWatchApplication).profiles
    private val tester = XrayDelayTester(application)
    private val settingsFlow = MutableStateFlow(repository.settings())
    private val monitoringFlow = MutableStateFlow(repository.isMonitoringEnabled())
    private val busyFlow = MutableStateFlow(false)
    private val messageFlow = MutableStateFlow<String?>(null)

    val uiState = combine(
        repository.profiles,
        settingsFlow,
        monitoringFlow,
        busyFlow,
        messageFlow
    ) { profiles, settings, monitoring, busy, message ->
        LinkWatchUiState(profiles, settings, monitoring, busy, message)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LinkWatchUiState())

    fun importLinks(text: String) {
        if (busyFlow.value) return
        viewModelScope.launch {
            busyFlow.value = true
            try {
                val parsed = ProxyLinkParser.importInput(text)
                val added = withContext(Dispatchers.IO) { repository.addAll(parsed) }
                messageFlow.value = if (added > 0) "$added کانفیگ اضافه شد" else "این لینک‌ها قبلاً اضافه شده‌اند"
            } catch (e: Exception) {
                messageFlow.value = e.message?.take(180) ?: "ورود لینک ناموفق بود"
            } finally {
                busyFlow.value = false
            }
        }
    }

    fun deleteProfile(profile: ProxyProfile) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.remove(profile.id)
            messageFlow.value = "${profile.name} حذف شد"
        }
    }

    fun testNow(profile: ProxyProfile) {
        viewModelScope.launch {
            val current = repository.getProfiles().firstOrNull { it.id == profile.id } ?: return@launch
            withContext(Dispatchers.IO) { repository.upsert(current.copy(state = LinkState.CHECKING)) }
            val result = tester.test(current, repository.settings())
            val threshold = repository.settings().failureThreshold
            val failures = if (result.success) 0 else current.consecutiveFailures + 1
            val nextState = when {
                result.success -> LinkState.CONNECTED
                failures >= threshold -> LinkState.DISCONNECTED
                else -> LinkState.UNSTABLE
            }
            withContext(Dispatchers.IO) { repository.upsert(current.copy(
                state = nextState,
                delayMs = result.delayMs,
                lastCheckedAt = System.currentTimeMillis(),
                consecutiveFailures = failures,
                lastError = if (result.success) "" else result.error
            )) }
            messageFlow.value = if (result.success) "${current.name}: ${result.delayMs} ms" else "تست ${current.name} ناموفق بود"
        }
    }

    fun saveSettings(settings: MonitorSettings) {
        val primaryValid = settings.primaryTestUrl.startsWith("https://", ignoreCase = true)
        val fallbackValid = settings.fallbackTestUrl.isBlank() || settings.fallbackTestUrl.startsWith("https://", ignoreCase = true)
        if (!primaryValid || !fallbackValid) {
            messageFlow.value = "برای حفظ امنیت، URL تست باید HTTPS باشد"
            return
        }
        repository.saveSettings(settings)
        settingsFlow.value = settings
        messageFlow.value = "تنظیمات ذخیره شد"
    }

    fun setMonitoring(enabled: Boolean) {
        repository.setMonitoringEnabled(enabled)
        monitoringFlow.value = enabled
        if (enabled) {
            MonitorController.start(getApplication())
            messageFlow.value = "پایش مداوم شروع شد"
        } else {
            MonitorController.stop(getApplication())
            messageFlow.value = "پایش متوقف شد"
        }
    }

    fun consumeMessage() {
        messageFlow.value = null
    }
}
