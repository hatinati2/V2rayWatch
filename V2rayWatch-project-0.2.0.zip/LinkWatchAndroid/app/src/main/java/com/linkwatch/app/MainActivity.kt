package com.linkwatch.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.linkwatch.app.ui.LinkWatchScreen
import com.linkwatch.app.ui.MainViewModel
import com.linkwatch.app.ui.MainViewModelFactory

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels { MainViewModelFactory(application) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedText = if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)
        } else null

        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF315BCE),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFE8EEFF),
                secondary = Color(0xFF52627A),
                background = Color(0xFFF6F7FB),
                surface = Color.White,
                surfaceVariant = Color(0xFFEEF1F7)
            )) {
                LinkWatchScreen(viewModel = viewModel, sharedText = sharedText)
            }
        }
    }
}
