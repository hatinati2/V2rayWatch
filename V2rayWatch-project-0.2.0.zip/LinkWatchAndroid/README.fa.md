# V2rayWatch — پایش Real Delay کانفیگ‌ها

**نسخهٔ آزمایشی: 0.2.0**

V2rayWatch یک اپ مستقل اندرویدی برای واردکردن لینک‌های پراکسی و بررسی واقعی کارکرد هر کانفیگ است. هدف آن جایگزین‌کردن v2rayNG نیست؛ فقط کانفیگ‌ها را نگه می‌دارد و برای هرکدام تست واقعی شبیه گزینهٔ Real Delay انجام می‌دهد.

## روش تست

برای هر پروفایل، برنامه یک نمونهٔ مستقل از Xray Core را با JSON همان پروفایل راه‌اندازی می‌کند و از طریق outbound آن یک درخواست HTTPS به URL آزمایشی می‌فرستد. زمان پاسخ و نتیجهٔ HTTP 200 یا 204 ثبت می‌شود. این تست صرفاً Ping، اتصال TCP یا بازبودن پورت نیست.

روش سنجش از `CoreController.measureDelay(url)` در AndroidLibXrayLite استفاده می‌کند؛ همان مسیر API که v2rayNG برای Real Delay به کار می‌برد. این متد درخواست را از داخل Core اجرا می‌کند و برای هر درخواست timeout دوازده‌ثانیه‌ای دارد. اگر URL اصلی شکست بخورد، URL جایگزین نیز امتحان می‌شود؛ بنابراین در شبکه‌ای که هر دو URL مسدود یا غیرقابل‌دسترسی باشند، یک پروفایل ممکن است بیش از ۲۰ ثانیه برای تکمیل تست زمان ببرد. کد منبع و جزئیات تابع در این فایل‌ها قابل بررسی است:

- https://github.com/2dust/AndroidLibXrayLite/blob/main/libv2ray_utils.go
- https://github.com/2dust/AndroidLibXrayLite/blob/main/libv2ray_main.go
- https://github.com/2dust/v2rayNG/blob/master/V2rayNG/app/src/main/java/com/v2ray/ang/core/CoreNativeManager.kt
- https://github.com/2dust/v2rayNG/blob/master/V2rayNG/app/src/main/java/com/v2ray/ang/core/CoreServiceManager.kt

URL اصلی پیش‌فرض `https://www.google.com/generate_204` و URL جایگزین `https://www.gstatic.com/generate_204` است. هر دو از تنظیمات برنامه قابل تغییرند. اگر تست اصلی شکست بخورد، URL جایگزین امتحان می‌شود.

## امکانات این نسخه

- واردکردن یک لینک یا چند لینک در چند خط
- واردکردن Subscription از طریق HTTPS
- دریافت لینک‌های کپی‌شده از برنامه‌های دیگر با Android Share
- اسکن QR کد لینک‌های پروکسی با دوربین گوشی
- پشتیبانی از `vless://`، `vmess://`، `trojan://`، `ss://`، `hysteria2://` و `hy2://`
- پشتیبانی از انتقال‌های رایج Xray شامل TCP، WebSocket، gRPC، HTTPUpgrade و XHTTP (با پارامترهای متداول path/host/mode/extra)
- واردکردن JSON کامل Xray که دارای `outbounds` باشد
- ذخیرهٔ محلی لینک و تنظیمات محرمانه با AES-GCM و Android Keystore
- تست دستی هر پروفایل
- پایش پس‌زمینه با Foreground Service و اعلان دائمی قابل مشاهده
- فاصلهٔ بررسی قابل تنظیم: ۲۰، ۳۰، ۶۰ یا ۱۲۰ ثانیه
- آستانهٔ خطای متوالی قابل تنظیم
- اعلان هنگام قطع‌شدن و بازیابی اتصال

## محدودیت‌های مهم

- این نسخه هنوز MVP آزمایشی است؛ روی گوشی فیزیکی نصب و تست نهایی نشده است.
- TUIC، WireGuard، SSH، Hysteria قدیمی (`hysteria://`) و افزونه‌های اختصاصی Shadowsocks در این نسخه پشتیبانی نمی‌شوند. برای Hysteria2 از لینک‌های `hysteria2://` یا `hy2://` استفاده کن.
- پشتیبانی Hysteria2 به قابلیت‌های نسخهٔ Xray همراه برنامه وابسته است؛ obfs نوع Salamander و پارامتر port hopping در لینک‌های استاندارد پردازش می‌شوند.
- بعضی پارامترهای پیشرفتهٔ transport ممکن است نیازمند توسعهٔ parser باشند. نتیجهٔ نهایی تست Core ملاک است.
- تست‌ها با حداکثر دو نمونهٔ Core هم‌زمان اجرا می‌شوند. اگر تعداد زیادی کانفیگ قطع باشند و هر تست timeout شود، یک دور کامل ممکن است بیش از ۲۰ ثانیه زمان ببرد؛ برنامه دورها را روی هم انباشته نمی‌کند.
- Xray Core برای تست هر پروفایل به‌صورت موقت اجرا و پس از تست بسته می‌شود؛ خود اپ یک VPN دائمی یا TUN فعال نمی‌کند.
- در Android، اجرای پایش مداوم نیازمند Foreground Service و اعلان دائمی است. کاربر باید پایش را از داخل برنامه شروع کند. Battery Saver و محدودیت‌های سازندهٔ گوشی ممکن است زمان‌بندی را عقب بیندازند. پس از راه‌اندازی مجدد خود گوشی، کاربر باید پایش را دوباره فعال کند.
- اگر VPN دیگری روی گوشی فعال باشد، Android ممکن است اتصال بیرونی خود V2rayWatch را هم از مسیر همان VPN عبور دهد؛ در این حالت تست لزوماً وضعیت مسیر خام اینترنت را نشان نمی‌دهد. برای مقایسهٔ مستقل، VPN دیگری را موقتاً خاموش کن.
- سرویس از نوع `specialUse` است. برای انتشار در Google Play باید کاربرد آن در Play Console توضیح داده و تأیید شود؛ صرف داشتن این نوع در Manifest تضمین پذیرش فروشگاه نیست.
- Subscription فقط از HTTPS دریافت می‌شود تا لینک حاوی credential روی HTTP ساده ارسال نشود.
- به‌دلیل استفاده از URLهای آزمایشی عمومی، بسته‌بودن آن دامنه‌ها در شبکهٔ کاربر می‌تواند نتیجهٔ منفی کاذب بدهد؛ URLها قابل تغییرند.

## ساخت APK

### پیش‌نیازها

- Android Studio با پشتیبانی از Android Gradle Plugin 8.9.2
- JDK 17
- Android SDK Platform 35 و Build Tools سازگار
- اینترنت هنگام اولین Build برای دریافت dependencyها و AAR هستهٔ Xray

### بازکردن پروژه

1. پوشهٔ `LinkWatchAndroid` را در Android Studio باز کن.
2. در اولین بار، Gradle task دریافت هسته را اجرا کن: `gradle :app:downloadXrayCore` (یا از پنجره Gradle در Android Studio، مسیر `app → Tasks → setup → downloadXrayCore`).
3. این task فایل رسمی `libv2ray.aar` نسخهٔ `v26.10.29` را از GitHub می‌گیرد و SHA-256 آن را با مقدار pin شده در `app/build.gradle.kts` تطبیق می‌دهد.
4. پس از دانلود موفق، Gradle Sync را اجرا کن.
5. از منوی **Build → Build APK(s)** خروجی Debug APK را بساز.

AAR عمداً داخل ZIP پروژه قرار داده نشده است؛ حجم آن حدود ۶۰ مگابایت است و برای جلوگیری از توزیع نسخهٔ بدون بررسی، هنگام Build از منبع upstream دریافت و checksum آن کنترل می‌شود.

### ساخت با ترمینال

از ریشهٔ پروژه، پس از نصب Gradle 8.11.1 یا سازگار:

```bash
gradle assembleDebug
```

خروجی معمول:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## امنیت و حریم خصوصی

- لینک‌ها و credentialهای داخل پروفایل در فضای خصوصی اپ ذخیره می‌شوند و با کلید AES نگهداری‌شده در Android Keystore رمزگذاری می‌شوند.
- برنامه telemetry یا حساب کاربری ندارد.
- لینک‌های خام و configها عمداً در Logcat نوشته نمی‌شوند.
- لینک Subscription فقط هنگام واردکردن دریافت می‌شود؛ URL اشتراک در دیتابیس پروفایل‌ها ذخیره نمی‌شود.
- URL تست، از داخل Core و از طریق outbound همان پروفایل درخواست می‌شود.

## وضعیت CI

فایل GitHub Actions در `.github/workflows/android.yml` پس از Push، پروژه را با JDK 17 و Android SDK می‌سازد و APK Debug را به‌عنوان artifact ذخیره می‌کند. این CI جایگزین تست روی دستگاه واقعی، تست OEM battery policy یا بررسی عملکرد تعداد زیادی پروفایل نیست.

## مجوزها و اجزای ثالث

کد مستقل V2rayWatch با MIT ارائه می‌شود. هستهٔ اندرویدی از AndroidLibXrayLite و Xray Core استفاده می‌کند؛ شرایط مجوز LGPL-3.0 و MPL-2.0 در پوشهٔ `licenses/` قرار دارند. اطلاعات upstream در `THIRD_PARTY_NOTICES.md` آمده است.
