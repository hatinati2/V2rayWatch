package com.linkwatch.app.monitor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.linkwatch.app.MainActivity

object NotificationHelper {
    const val CHANNEL_MONITOR = "linkwatch_monitor"
    const val CHANNEL_ALERTS = "linkwatch_alerts"
    const val ONGOING_ID = 4101

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_MONITOR, "وضعیت پایش", NotificationManager.IMPORTANCE_LOW).apply {
                description = "اعلان دائمی هنگام فعال بودن پایش لینک‌ها"
                setShowBadge(false)
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "هشدار قطع و وصل لینک", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "هشدار هنگام قطع شدن یا بازیابی اتصال واقعی پروکسی"
                enableVibration(true)
                setShowBadge(true)
            }
        )
    }

    fun ongoing(context: Context, checked: Int, total: Int) = NotificationCompat.Builder(context, CHANNEL_MONITOR)
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentTitle("LinkWatch در حال پایش است")
        .setContentText("$checked از $total لینک بررسی شده‌اند")
        .setContentIntent(openAppIntent(context))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    fun notifyDisconnected(context: Context, profileName: String, reason: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("لینک قطع شده است: $profileName")
            .setContentText(reason.ifBlank { "تست اتصال واقعی ناموفق بود" })
            .setStyle(NotificationCompat.BigTextStyle().bigText("$profileName\n${reason.ifBlank { "تست اتصال واقعی ناموفق بود" }}"))
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ERROR)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(profileName.hashCode(), notification) }
    }

    fun notifyRecovered(context: Context, profileName: String, delayMs: Long) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("اتصال دوباره برقرار شد: $profileName")
            .setContentText("Real Delay: ${delayMs} ms")
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(profileName.hashCode(), notification) }
    }

    private fun openAppIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
